﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Management;

namespace MiniDownloadManager
{
    public partial class MainWindow : Window
    {
        private List<DownloadItem> _items = new();
        private int _currentIndex = 0;
        private readonly string historyFile = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "downloaded_files.txt");
        public MainWindow()
        {
            InitializeComponent();
            LoadItems();
        }

        private async void LoadItems()
        {
            try
            {
                var json = await new HttpClient().GetStringAsync("https://4qgz7zu7l5um367pzultcpbhmm0thhhg.lambda-url.us-west-2.on.aws/");
                _items = JsonSerializer.Deserialize<List<DownloadItem>>(json);
                _items = _items.OrderByDescending(i => i.Score).ToList();
                NextValidItem();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load items: " + ex.Message);
            }
        }

        private void NextValidItem()
        {
            while (_currentIndex < _items.Count)
            {
                var item = _items[_currentIndex];
                if (IsValid(item))
                {
                    TitleLabel.Content = item.Title;
                    ItemImage.Source = new BitmapImage(new Uri(item.ImageURL));
                    return;
                }
                _currentIndex++;
            }
        }

        private bool IsValid(DownloadItem item)
        {
            if (item.Validators == null) return true;
            foreach (var validator in item.Validators)
            {
                if (validator.Key == "ram")
                {
                    var needed = int.Parse(validator.Value);
                    var available = GetPhysicalMemoryInGB();
                    if (available < needed) return false;
                }
                if (validator.Key == "os")
                {
                    if (!Environment.OSVersion.VersionString.Contains(validator.Value)) return false;
                }
                if (validator.Key == "disk")
                {
                    var drive = DriveInfo.GetDrives().FirstOrDefault(d => d.IsReady && d.Name.StartsWith(System.IO.Path.GetPathRoot(System.IO.Path.GetTempPath())));
                    if (drive?.AvailableFreeSpace < long.Parse(validator.Value)) return false;
                }
            }
            return true;
        }
        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            _currentIndex++;
            NextValidItem();
        }
        private async void DownloadButton_Click(object sender, RoutedEventArgs e)
        {
            var item = _items[_currentIndex];
            var fileName = System.IO.Path.Combine(System.IO.Path.GetTempPath(), System.IO.Path.GetFileName(new Uri(item.FileURL).LocalPath));

            if (File.Exists(historyFile) && File.ReadAllLines(historyFile).Contains(fileName))
            {
                MessageBox.Show("You've already downloaded this file before.");
                return;
            }

            try
            {
                using var client = new HttpClient();
                var bytes = await client.GetByteArrayAsync(item.FileURL);
                await File.WriteAllBytesAsync(fileName, bytes);
                File.AppendAllLines(historyFile, new[] { fileName });

                Process.Start(new ProcessStartInfo(fileName) { UseShellExecute = true });
                Process.Start("explorer.exe", "/select," + fileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Download failed: " + ex.Message);
            }
        }
        public class DownloadItem
        {
            public string Title { get; set; }
            public string ImageURL { get; set; }
            public string FileURL { get; set; }
            public int Score { get; set; }
            public Dictionary<string, string> Validators { get; set; }
        }
        private double GetPhysicalMemoryInGB()
        {
            double totalMemory = 0;
            var searcher = new ManagementObjectSearcher("SELECT Capacity FROM Win32_PhysicalMemory");
            foreach (var obj in searcher.Get())
            {
                totalMemory += Convert.ToDouble(obj["Capacity"]);
            }
            return totalMemory / (1024 * 1024 * 1024); // GB
        }


    }
}